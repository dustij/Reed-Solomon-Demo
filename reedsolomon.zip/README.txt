Run app.jar located in target/dist/

To do list

[ ] Polynomial labels with not show anything until Encode is clicked, then it will fill in coeffecients accordingly
[ ] Restrict the message text field to 12 characters
[x] Replace spinners with custom hex spinners
[ ] Clicking Encode will also populate the hex spinners the same time polynomial labels are generated
[ ] Change color for spinners that are modified by the user
[ ] Ensure formatting and spacing looks nice (spinners are same width, spacing and padding, etc.)
[ ] Add the last section on decoding